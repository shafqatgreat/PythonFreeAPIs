


import requests  


new_post = {
    "title": "My First Post",
    "body": "This is the body of the post.",
    "userId": 1
}


r = requests.post("https://jsonplaceholder.typicode.com/posts", json=new_post)

print("📬 Created Post ID:", r.json()["id"])

print("🧾 Response:", r.json())




