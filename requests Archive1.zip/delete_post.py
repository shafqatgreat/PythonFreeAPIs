
import requests

r = requests.delete("https://jsonplaceholder.typicode.com/posts/1")  
print("🗑️ Deletion Status Code:", r.status_code)
print("✅ Deleted Successfully!" if r.status_code == 200 else "❌ Failed to Delete")
