import requests

# **********************************************************************
# r = requests.get("https://api.exchangerate-api.com/v4/latest/USD")  
# print(r.json()["rates"]["PKR"])

# **********************************************************************
# r = requests.get("https://ipinfo.io/json")  
# print(f"IP: {r.json()['ip']}, City: {r.json()['city']}")

# **********************************************************************
# r = requests.get("https://source.unsplash.com/random")  
# with open("image.jpg", "wb") as f: f.write(r.content)
# **********************************************************************
# r = requests.get("https://api.github.com/users/torvalds")  
# print(f"Username: {r.json()['login']} - Bio: {r.json()['bio']}")

# **********************************************************************
# r = requests.get("https://randomuser.me/api/?results=2")  
# for user in r.json()["results"]: print(user["name"]["first"], user["email"])

# **********************************************************************
# country = "Pakistan"  # You can change this to any country name
# r = requests.get(f"https://disease.sh/v3/covid-19/countries/{country}")
# data = r.json()

# print(f"Country: {data['country']}")
# print(f"Total Cases: {data['cases']}")
# print(f"Active Cases: {data['active']}")
# print(f"Recovered: {data['recovered']}")
# print(f"Deaths: {data['deaths']}")

# # **********************************************************************
# r = requests.get("https://disease.sh/v3/covid-19/countries")
# for country in r.json():
#     print(f"{country['country']}: {country['cases']} cases")
# # **********************************************************************



def get_weather(city):
    url = f'https://wttr.in/{city}?format=%C+%t+%w'
    response = requests.get(url)
    if response.status_code == 200:
        return response.text
    else:
        return "Error fetching weather data"

# Example usage
city = 'Lahore'
weather_data = get_weather(city)
print(f"********Weather***********")
print(f"Weather in {city}: {weather_data}")
print(f"**************************")
