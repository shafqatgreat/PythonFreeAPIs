

import requests

def get_weather(city):
    url = f'https://wttr.in/{city}?format=%C+%t+%w'
    response = requests.get(url)
    if response.status_code == 200:
        return response.text
    else:
        return "Error fetching weather data"

# Example usage
city = 'London'
weather_data = get_weather(city)
print("******************************************")
print(f"Weather in {city}: {weather_data}")
print("******************************************")

