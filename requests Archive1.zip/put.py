
import requests

updated_post = {
    "id": 1,
    "title": "Updated Title",
    "body": "Updated content body.",
    "userId": 1
}

r = requests.put("https://jsonplaceholder.typicode.com/posts/1", json=updated_post)

print("🔄 Updated Post:", r.json())
